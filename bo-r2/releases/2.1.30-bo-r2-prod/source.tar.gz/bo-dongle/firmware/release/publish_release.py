"""Publish immutable release files, then advance the public device manifest.

  --input signed --channel stable   offer a new release to every dongle
  --input signed --channel test     offer a new release only to the test dongles
  --promote VERSION                 offer the current test release, unchanged, to every dongle
  --testers-only                    write the test dongle list again, nothing else

The manifest's top-level fields are the stable release. Its optional "test"
object holds a newer release and the device IDs from test-devices.json;
firmware 2.1.29+ installs it only on those dongles. Older firmware ignores it.
"""
import argparse,hashlib,json,re,shutil,subprocess,tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
VERSION=re.compile(r'\d{1,3}\.\d{1,3}\.\d{1,3}-bo-r2-prod')
MAX_MANIFEST=4000   # The dongle refuses a manifest larger than 4096 bytes.
p=argparse.ArgumentParser()
mode=p.add_mutually_exclusive_group(required=True)
mode.add_argument('--input',type=Path,help='signed release directory')
mode.add_argument('--promote',metavar='VERSION',help='the current test version to offer to every dongle')
mode.add_argument('--testers-only',action='store_true',help='only update the test dongle list')
p.add_argument('--channel',choices=('stable','test'),help='required with --input')
p.add_argument('--testers',type=Path,default=HERE/'test-devices.json')
p.add_argument('--repository',default='git@github.com:mcstech1/bo-dongle-updates.git')
a=p.parse_args()
if bool(a.input)!=bool(a.channel):p.error('--channel goes with --input only')

def number(v):
    assert isinstance(v,str) and VERSION.fullmatch(v),'Invalid version '+repr(v)
    return tuple(map(int,v.split('-')[0].split('.')))
devices=json.loads(a.testers.read_text())
assert isinstance(devices,list) and len(devices)<=16 and len(set(devices))==len(devices) and \
    all(isinstance(d,str) and re.fullmatch(r'[0-9A-F]{12}',d) for d in devices),'test-devices.json must list up to 16 device IDs like 3CDC75FDC9C0'
if a.input:
    release=json.loads((a.input/'release.json').read_text());version=release['version'];number(version)
    for file,key in [('firmware.bin','sha256'),('source.tar.gz','source_sha256')]:assert hashlib.sha256((a.input/file).read_bytes()).hexdigest()==release[key]
if a.promote:number(a.promote)

with tempfile.TemporaryDirectory(prefix='bo-publish-') as directory:
    checkout=Path(directory)/'updates'
    subprocess.run(['git','clone','-q',a.repository,str(checkout)],check=True)
    def git(*args):return subprocess.check_output(['git',*args],cwd=checkout,text=True).strip()
    git('config','user.name','BO Dongle release');git('config','user.email','41898282+github-actions[bot]@users.noreply.github.com')
    # Always work on the remote main branch, whatever the remote HEAD names.
    if subprocess.run(['git','rev-parse','-q','--verify','refs/remotes/origin/main'],cwd=checkout,capture_output=True).returncode==0:
        git('checkout','-q','-B','main','origin/main')
    else:
        git('symbolic-ref','HEAD','refs/heads/main')   # New, empty feed repository.
    feed_path=checkout/'bo-r2/stable.json'
    stable=json.loads(feed_path.read_text()) if feed_path.exists() else None
    test=stable.pop('test',None) if stable else None
    if stable:number(stable['version'])
    if test:number(test['version'])
    if a.input:
        if stable:assert number(version)>number(stable['version']),'Do not replace or downgrade a published release'
        if a.channel=='test':
            assert stable,'Publish a stable release first; older firmware reads only the stable fields'
            assert devices,'test-devices.json lists no dongle'
            if test:assert number(version)>number(test['version']),'Test releases must also advance'
        target=checkout/'bo-r2/releases'/version
        assert not target.exists(),'Release files are immutable; use --promote to offer a tested release to every dongle'
        target.mkdir(parents=True)
        for name in ('firmware.bin','source.tar.gz','release.json'):shutil.copyfile(a.input/name,target/name)
        (checkout/'README.md').write_text('# BO Dongle updates\n\nSigned firmware and matching release source for the R2 dongle. The setup page checks `bo-r2/stable.json`. Its top-level fields are the release for every dongle. An optional `test` entry offers a newer release first to the listed device IDs (firmware 2.1.29 and later). Updates are verified on the device before installation. Source development history and signing keys remain private.\n\nRelease files are under `bo-r2/releases/<version>/`. Each release contains `firmware.bin`, `source.tar.gz` and checksums in `release.json`. Hardware security state is recorded explicitly; OTA signatures alone do not imply USB readout protection.\n')
        git('add','README.md',str(target.relative_to(checkout)));git('commit','-q','-m','Publish signed firmware '+version)
        assets=git('rev-parse','HEAD');base='https://raw.githubusercontent.com/mcstech1/bo-dongle-updates/'+assets+'/bo-r2/releases/'+version+'/'
        entry=dict(release,url=base+'firmware.bin',source_url=base+'source.tar.gz')
        if a.channel=='stable':
            stable=entry
            if test and number(test['version'])<=number(version):test=None
            message='Offer '+version+' to all dongles'
        else:
            test=entry;message='Offer '+version+' to test dongles'
    elif a.promote:
        assert test and test['version']==a.promote,'Only the current test release can be promoted; it is '+(test['version'] if test else 'absent')
        assert number(test['version'])>number(stable['version'])
        stable={k:v for k,v in test.items() if k!='devices'};test=None
        message='Offer tested '+a.promote+' to all dongles'
    else:
        assert stable,'No published feed'
        message='Update the test dongle list'
    manifest=dict(stable)
    if test:manifest['test']=dict({k:v for k,v in test.items() if k!='devices'},devices=devices)
    text=json.dumps(manifest,indent=2)+'\n'
    assert len(text.encode())<=MAX_MANIFEST,'Manifest too large for the dongle'
    feed_path.parent.mkdir(parents=True,exist_ok=True);feed_path.write_text(text)
    git('add',str(feed_path.relative_to(checkout)))
    if not git('status','--porcelain'):print('Feed already current; nothing published');raise SystemExit(0)
    git('commit','-q','-m',message)
    git('push','-q','origin','main')
    print(message+'; stable '+stable['version']+(', test '+test['version']+' for '+', '.join(devices) if test else ', no test release'))
