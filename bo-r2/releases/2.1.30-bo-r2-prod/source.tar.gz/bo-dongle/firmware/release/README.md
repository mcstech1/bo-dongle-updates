# Publish an update

Commit the code and a newer `firmware/VERSION` to the private repository's `main` branch. Open **Actions → Release firmware → Run workflow** and select `action`:

- `build`: signed artifact for testing, nothing published.
- `test`: offer the release to the test dongles in `test-devices.json` only.
- `promote` with `version`: offer the current test release, unchanged, to all dongles (no build).
- `stable`: build and offer to all dongles at once, without a test cycle.
- `testers`: write `test-devices.json` into the feed again (remove a dongle before it leaves the owner).

See `../docs/UPDATE-CHANNELS.md`.

The workflow compiles in a pinned SDK container without signing credentials. A separate job in the main-only `production` environment verifies the build artifact and signs it. Publication uses a deploy key scoped only to the public update repository. `promote` and `testers` change only the feed and need neither the build nor the signing key. Devices never receive either key or a personal GitHub token.

Published version folders cannot be replaced. The device manifest points to files by immutable Git commit, verifies HTTPS, SHA-256 and the firmware signature, and advances only to newer versions. The source archive contains buildable release source and notices, not private repository history or device identity files. The owner handles the buyer-facing QR code.

The repository's GitHub plan does not support required environment reviewers; the workflow therefore remains manually dispatched and main-only. Do not expose either secret to pull-request workflows.
