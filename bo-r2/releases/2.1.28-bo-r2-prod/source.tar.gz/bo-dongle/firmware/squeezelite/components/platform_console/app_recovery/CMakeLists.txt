idf_component_register( SRC_DIRS .
						INCLUDE_DIRS .   
						PRIV_REQUIRES bootloader_support
 )
 
target_link_libraries(${COMPONENT_LIB} INTERFACE "-Wl,--undefined=esp_app_desc")	
idf_build_get_property(project_ver PROJECT_VER)
message("******************* ${project_ver}")
string(SUBSTRING "${project_ver}" 0 31 PROJECT_VER_CUT)
if(CONFIG_BO_PRODUCTION)
    # Recovery must accept the current official application, including when
    # restoring the same release after an application/configuration failure.
    set(PROJECT_VER_CUT "0.0.3-bo-r2-prod")
endif()
set_source_files_properties(recovery.c PROPERTIES COMPILE_DEFINITIONS "PROJECT_VER=\"${PROJECT_VER_CUT}\"")
