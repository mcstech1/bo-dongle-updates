"""Sign the build artifact in a separate job; keep the release key out of git."""
import argparse,hashlib,json,os,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];build=json.loads((a.input/'build.json').read_text());image=(a.input/'unsigned.bin').read_bytes();source=(a.input/'source.tar.gz').read_bytes()
assert hashlib.sha256(image).hexdigest()==build['unsigned_sha256']
assert hashlib.sha256(source).hexdigest()==build['source_sha256']
assert image[48:80].split(b'\0')[0].decode()==build['version']
assert image[80:112].split(b'\0')[0]==b'Squeezelite-ESP32'
if os.environ.get('GITHUB_SHA'):assert build['source_commit']==os.environ['GITHUB_SHA']
key=os.environ.get('BO_RELEASE_SIGNING_KEY');assert key,'Release environment signing key unavailable'
secure=Path(os.environ['IDF_PATH'])/'components/esptool_py/esptool/espsecure.py'
a.output.mkdir(parents=True,exist_ok=True)
with tempfile.NamedTemporaryFile(prefix='bo-release-key-',suffix='.pem') as temporary:
 temporary.write(key.encode());temporary.flush()
 subprocess.run(['python',str(secure),'sign_data','--version','2','--keyfile',temporary.name,'--output',str(a.output/'firmware.bin'),str(a.input/'unsigned.bin')],check=True)
subprocess.run(['python',str(secure),'verify_signature','--version','2','--keyfile',str(root/'firmware/keys/release-rsa3072.pub'),str(a.output/'firmware.bin')],check=True)
raw=(a.output/'firmware.bin').read_bytes();assert len(raw)%4096==0 and len(raw)<=0x500000
(a.output/'source.tar.gz').write_bytes(source)
manifest={k:build[k] for k in ('target','version','source_commit','source_sha256','hardware_secure_boot','hardware_flash_encryption')}
manifest.update(size=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(a.output/'release.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Verified signed release '+build['version'])
