# Publish an update

Commit the code and a newer `firmware/VERSION` to the private repository's `main` branch. Open **Actions → Release firmware → Run workflow**. Leave publication off to obtain a signed artifact for testing. Enable publication when offering the committed version to dongles.

The workflow compiles in a pinned SDK container without signing credentials. A separate job in the main-only `production` environment verifies the build artifact and signs it. Publication uses a deploy key scoped only to the public update repository. Devices never receive either key or a personal GitHub token.

Published version folders cannot be replaced. The device manifest points to files by immutable Git commit, verifies HTTPS, SHA-256 and the firmware signature, and advances only to newer versions. The source archive contains buildable release source and notices, not private repository history or device identity files. The owner handles the buyer-facing QR code.

The repository's GitHub plan does not support required environment reviewers; the workflow therefore remains manually dispatched and main-only. Do not expose either secret to pull-request workflows.
