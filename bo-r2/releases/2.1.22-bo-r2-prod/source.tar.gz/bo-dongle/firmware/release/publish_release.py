"""Publish immutable release files, then advance the public device manifest."""
import argparse,hashlib,json,re,shutil,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--repository',default='git@github.com:mcstech1/bo-dongle-updates.git');a=p.parse_args()
release=json.loads((a.input/'release.json').read_text());version=release['version']
assert re.fullmatch(r'\d{1,3}\.\d{1,3}\.\d{1,3}-bo-r2-prod',version)
for file,key in [('firmware.bin','sha256'),('source.tar.gz','source_sha256')]:assert hashlib.sha256((a.input/file).read_bytes()).hexdigest()==release[key]
def number(v):return tuple(map(int,v.split('-')[0].split('.')))
with tempfile.TemporaryDirectory(prefix='bo-publish-') as directory:
 checkout=Path(directory)/'updates'
 subprocess.run(['git','clone',a.repository,str(checkout)],check=True)
 def git(*args):return subprocess.check_output(['git',*args],cwd=checkout,text=True).strip()
 git('config','user.name','BO Dongle release');git('config','user.email','41898282+github-actions[bot]@users.noreply.github.com')
 if not git('branch','--show-current'):git('checkout','-b','main')
 if git('branch','--show-current')!='main':git('checkout','-B','main')
 feed=checkout/'bo-r2/stable.json'
 if feed.exists():assert number(version)>number(json.loads(feed.read_text())['version']),'Do not replace or downgrade a published release'
 target=checkout/'bo-r2/releases'/version;assert not target.exists(),'Release files are immutable'
 target.mkdir(parents=True)
 for name in ('firmware.bin','source.tar.gz','release.json'):shutil.copyfile(a.input/name,target/name)
 (checkout/'README.md').write_text('# BO Dongle updates\n\nSigned firmware and matching release source for the R2 dongle. The setup page checks `bo-r2/stable.json`. Updates are verified on the device before installation. Source development history and signing keys remain private.\n\nRelease files are under `bo-r2/releases/<version>/`. Each release contains `firmware.bin`, `source.tar.gz` and checksums in `release.json`. Hardware security state is recorded explicitly; OTA signatures alone do not imply USB readout protection.\n')
 git('add','README.md',str(target.relative_to(checkout)));git('commit','-m','Publish signed firmware '+version)
 assets=git('rev-parse','HEAD');base='https://raw.githubusercontent.com/mcstech1/bo-dongle-updates/'+assets+'/bo-r2/releases/'+version+'/'
 manifest=dict(release,url=base+'firmware.bin',source_url=base+'source.tar.gz')
 feed.write_text(json.dumps(manifest,indent=2)+'\n');git('add',str(feed.relative_to(checkout)));git('commit','-m','Offer '+version+' to dongles')
 git('push','origin','main')
 print('Published '+version+'; devices fetch immutable signed files from '+assets)
