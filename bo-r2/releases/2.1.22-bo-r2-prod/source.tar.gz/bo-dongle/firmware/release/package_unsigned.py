"""Package one exact source revision and its unsigned R2 application for signing."""
import argparse,gzip,hashlib,json,re,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--build',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2];version=(root/'firmware/VERSION').read_text().strip()
assert re.fullmatch(r'\d{1,3}\.\d{1,3}\.\d{1,3}-bo-r2-prod',version)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root).strip(),'Commit the exact release source before packaging'
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root).strip(),'Commit all release source before packaging'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
cfg=json.loads((a.build/'config/sdkconfig.json').read_text())
checks={'IDF_TARGET':'esp32s3','ESPTOOLPY_FLASHMODE':'dio','ESPTOOLPY_FLASHSIZE':'16MB','SPIRAM_MODE_OCT':True,'SPIRAM_MEMTEST':True,'ESP_CONSOLE_USB_SERIAL_JTAG':True,'SECURE_SIGNED_ON_UPDATE':True,'BOOTLOADER_APP_ROLLBACK_ENABLE':True,'I2S_BCK_IO':4,'I2S_WS_IO':5,'I2S_DO_IO':6,'MUTE_GPIO':7}
for key,value in checks.items():assert cfg.get(key)==value,(key,cfg.get(key))
assert not re.search(r'^\.bss\.\S',(a.build/'squeezelite.map').read_text(),re.M),'Orphan BSS'
image=(a.build/'squeezelite.bin').read_bytes();assert len(image)<0x4ff000 and image[0]==0xe9
assert image[48:80].split(b'\0')[0].decode()==version
assert image[80:112].split(b'\0')[0]==b'Squeezelite-ESP32'
# Deliberately package buildable release source, not private development history,
# device records, bench logs, raw flash backups or personal configuration files.
paths=['firmware/squeezelite','firmware/VERSION','firmware/tools/build.sh','firmware/README.md','firmware/docs/BOARD-CONTRACT.md','firmware/docs/OWNER-RECOVERY.md','firmware/keys/release-rsa3072.pub','firmware/release']
archive=subprocess.check_output(['git','archive','--format=tar','--prefix=bo-dongle/',revision,*paths],cwd=root)
epoch=int(subprocess.check_output(['git','show','-s','--format=%ct',revision],cwd=root))
source=gzip.compress(archive,mtime=epoch)
a.output.mkdir(parents=True,exist_ok=True)
(a.output/'unsigned.bin').write_bytes(image);(a.output/'source.tar.gz').write_bytes(source)
manifest={'target':'bo-r2','version':version,'source_commit':revision,'unsigned_sha256':hashlib.sha256(image).hexdigest(),'source_sha256':hashlib.sha256(source).hexdigest(),'hardware_secure_boot':bool(cfg.get('SECURE_BOOT')),'hardware_flash_encryption':bool(cfg.get('SECURE_FLASH_ENC_ENABLED'))}
(a.output/'build.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Packaged '+version+' from '+revision)
