/* Console example — declarations of command registration functions.

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#pragma once
#include "nvs_flash.h"

#ifdef __cplusplus
extern "C" {
#endif

// Register NVS functions
void register_nvs();

#ifdef __cplusplus
}
#endif

