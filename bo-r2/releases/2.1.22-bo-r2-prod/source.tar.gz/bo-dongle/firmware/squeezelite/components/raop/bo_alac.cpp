#include "bo_alac.h"
#include "../spotify/cspot/bell/external/alac/codec/ALACDecoder.h"
#include "../spotify/cspot/bell/external/alac/codec/ALACBitUtilities.h"
#include <new>

// The existing libalac.a supplies these Apple codec methods. Its generic
// wrapper assumes an encoded packet cannot exceed its decoded PCM size.
// RAOP escape frames need extra header bytes, so pass the actual packet size.
#ifdef ESP_PLATFORM
static_assert(sizeof(ALACDecoder)==44,"Prebuilt ALAC decoder ABI changed");
#endif

void *bo_alac_create(void *cookie,unsigned cookie_size) {
    ALACDecoder *decoder=new(std::nothrow) ALACDecoder;
    if (!decoder) return nullptr;
    if (decoder->Init(cookie,cookie_size)) { delete decoder;return nullptr; }
    return decoder;
}
void bo_alac_destroy(void *decoder) { delete static_cast<ALACDecoder*>(decoder); }
bool bo_alac_decode(void *opaque,unsigned char *packet,unsigned packet_bytes,
                    unsigned char *output,unsigned capacity_frames,unsigned *frames) {
    *frames=0;
    if (!opaque || packet_bytes<8 || !capacity_frames) return false;
    // This receiver advertises 16-bit stereo only. Validate the first channel
    // pair's optional frame count before the legacy codec can write samples.
    BitBuffer prefix;BitBufferInit(&prefix,packet,packet_bytes);
    if (BitBufferRead(&prefix,3)!=1) return false;
    BitBufferAdvance(&prefix,16); // instance tag and reserved bits
    unsigned flags=BitBufferRead(&prefix,4);
    unsigned count=capacity_frames;
    if (flags & 8) {
        if (packet_bytes<7) return false;
        count=BitBufferRead(&prefix,16)<<16;
        count|=BitBufferRead(&prefix,16);
        if (!count || count>capacity_frames) return false;
    }
    if (flags & 1) {
        unsigned header_bits=(flags & 8) ? 55 : 23;
        if (packet_bytes<(header_bits+count*32+3+7)/8) return false;
    }
    auto *decoder=static_cast<ALACDecoder*>(opaque);
    if (decoder->mConfig.frameLength>capacity_frames) return false;
    BitBuffer bits;BitBufferInit(&bits,packet,packet_bytes);
    uint32_t decoded=0;
    int status=decoder->Decode(&bits,output,capacity_frames,2,&decoded);
    if (status || !decoded || decoded>capacity_frames) return false;
    *frames=decoded;return true;
}
