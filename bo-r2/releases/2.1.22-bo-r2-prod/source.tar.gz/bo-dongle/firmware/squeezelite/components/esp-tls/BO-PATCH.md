# Bounded TLS setup handshake

Vendored from Espressif ESP-IDF v4.4.8, unchanged except the server handshake deadline in esp_tls_mbedtls.c and its esp_timer build dependency. Original Apache-2.0 notices are retained.

The original synchronous server handshake loops indefinitely on WANT_READ/WANT_WRITE, even after the socket receive timeout. A browser preconnection or a stalled client can therefore block all HTTPS setup requests. The patched server allows five seconds total and polls at one second while handshaking, then restores the HTTP server timeout. Certificate verification and cryptographic settings are unchanged.

This is a compatibility fix for validation, not a claim that ESP-IDF 4.4 is supported. Reassess/remove it when moving to a supported SDK.
