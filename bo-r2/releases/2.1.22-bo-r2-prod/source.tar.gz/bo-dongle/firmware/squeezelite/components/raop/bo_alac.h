#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
void *bo_alac_create(void *cookie, unsigned cookie_size);
void bo_alac_destroy(void *decoder);
bool bo_alac_decode(void *decoder, unsigned char *packet, unsigned packet_bytes,
                    unsigned char *output, unsigned capacity_frames, unsigned *frames);
#ifdef __cplusplus
}
#endif
