#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>

enum bo_raop_codec { BO_RAOP_UNSUPPORTED, BO_RAOP_ALAC, BO_RAOP_L16 };
// 352 stereo PCM frames already occupy 1408 bytes. The received UDP packet
// also contains RTP headers, ALAC escape overhead and possible resend headers.
#define BO_RAOP_PACKET_BYTES 2048

static inline enum bo_raop_codec bo_raop_codec_from_sdp(const char *sdp) {
    if (!sdp) return BO_RAOP_UNSUPPORTED;
    const char *line = sdp;
    while (*line) {
        size_t length = strcspn(line, "\r\n");
        const char alac[] = "a=rtpmap:96 AppleLossless";
        const char pcm[] = "a=rtpmap:96 L16/44100/2";
        if (length == sizeof(alac)-1 && !memcmp(line, alac, length)) return BO_RAOP_ALAC;
        if (length == sizeof(pcm)-1 && !memcmp(line, pcm, length)) return BO_RAOP_L16;
        line += length;
        while (*line == '\r' || *line == '\n') line++;
    }
    return BO_RAOP_UNSUPPORTED;
}

/* RFC 3551 L16 samples are signed, network byte order, left/right interleaved. */
static inline bool bo_raop_l16_decode(const uint8_t *input, size_t bytes,
                                     int16_t *output, size_t capacity_frames,
                                     unsigned *frames) {
    *frames = 0;
    if (!bytes || bytes % 4 || bytes / 4 > capacity_frames) return false;
    for (size_t i = 0; i < bytes / 2; i++) {
        unsigned sample = ((unsigned)input[2*i] << 8) | input[2*i+1];
        output[i] = sample >= 32768 ? (int)sample - 65536 : (int)sample;
    }
    *frames = bytes / 4;
    return true;
}
