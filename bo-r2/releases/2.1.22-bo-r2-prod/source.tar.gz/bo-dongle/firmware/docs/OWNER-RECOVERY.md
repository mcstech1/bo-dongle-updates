# Owner recovery for the single-board trial

The buyer setup card supplies the board's open network name and HTTP setup address. Normal setup needs only the buyer's home Wi-Fi password. The unique service code and TLS identity remain in the separate device service record for maintenance and recovery. Neither record should contain a previous owner's home network or Spotify account.

## Restore the official software

Normally the dongle checks the public update feed automatically when connected and idle. The authenticated HTTPS service page can check immediately or upload an official signed image with its SHA-256 checksum.

If the application does not complete a new boot, its previous validated image is selected on the next reset. A separate signed recovery application also retains Wi-Fi setup and official update download. A technician can enter it through the native USB console with `bo-recovery <setup-code>`. Recovery keeps the unique factory identity. It can reinstall the current official release; it need not wait for a newer release.

`bo-factory-reset <setup-code>` erases saved networks, Spotify login and owner preferences. Pause playback first. Reset preserves the setup code and device certificate. USB commands are sent at 115200 baud without changing GPIO0/EN manually.

## Installing owner modifications

This trial board has no hardware Secure Boot or Flash Encryption locks. Its authenticated official updater accepts only manufacturer-signed releases, but its USB ROM loader remains available for owner firmware installation. The owner does not need the manufacturer signing key to build or install their own firmware through that route. The 2.1.12 application provides normal Wi-Fi setup through an open access point and `http://192.168.4.1/` without a login. The older factory recovery image on an already provisioned board retains its service-code setup until separately updated; normal application OTA does not overwrite that recovery partition.

Build the matching source using the documented SDK and dependencies. Before modifying the board, back up all 16 MB privately; this includes that board's setup identity and secrets. Keep the partition table and factory identity/key partitions intact. The common build output's full-flash command is not a safe owner upgrade command. Choosing and writing an inactive application slot requires checking the existing OTA metadata first. `stage_validation.py` illustrates that procedure but deliberately refuses all boards except the second bench unit; adapt and review the installer for your own hardware and signing configuration.

Any future hardware locking changes this procedure and requires separate per-device installation material. Do not assume this USB recovery method applies to a hardware-locked board.
