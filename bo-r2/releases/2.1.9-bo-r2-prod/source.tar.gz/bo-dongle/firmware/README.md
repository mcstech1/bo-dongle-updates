# BO Dongle R2 firmware

Spotify Connect and AirPlay audio over AUX, with automatic B&O AUX wake and five-minute idle standby. The physically verified home-unit release is preserved at tag `v2.0.0-r2-verified-20260907`.

This branch prepares the second board for a single-unit trial. It keeps the working audio implementation and adds individual buyer setup and signed updates. The broad SDK migration is paused at the owner's request. See `docs/BUYER-RELEASE-PLAN.md` for current validation status.

## Buyer setup

1. Connect AUX and USB power.
2. Join the `BO-Dongle-Setup-XXXX` network using the individual setup code supplied with the board.
3. Open `https://192.168.4.1/`. The device uses an individual certificate: compare its fingerprint with the supplied setup card before accepting the browser warning. Sign in as `bo` with the setup code.
4. Enter the buyer's 2.4 GHz Wi-Fi name and password, then reconnect the phone/computer to that network.
5. Select the board's individual name in Spotify or AirPlay. No personal Spotify account is compiled into the firmware.

The settings address and setup code remain on the supplied card. Factory reset erases remembered networks, Spotify credentials and owner preferences; it retains the device identity and setup code. A lost home network brings back the secured setup access point after two minutes.

## Updates

The active release service is `https://raw.githubusercontent.com/mcstech1/bo-dongle-updates/main/bo-r2/stable.json`. The dongle verifies both HTTPS and an RSA-3072 firmware signature before selecting an inactive application slot. A failed boot rolls back. The receiver checks after startup and then hourly while idle, with retries after temporary failures. Official signing keys stay outside the source tree and outside devices.

Automatic updates can be disabled on the settings page. An authenticated owner can also check manually or upload an official signed image. Updates wait for playback to stop. USB signing/readout protection is a separate hardware-security step and is not implied by OTA signatures.

## Build

Use ESP-IDF v4.4.8 at commit `e499576efdb086551abe309a72899302f82077b7`, including its recursive submodules, and install/export its ESP32-S3 toolchain. Then run:

```sh
python -m pip install -r firmware/release/requirements-build.txt
BO_BUILD_ROOT=/tmp/bo-dongle-build bash firmware/tools/build.sh reconfigure build
```

`firmware/VERSION` supplies the application version; `BO_PROJECT_VERSION` can override it. The build copies source to a path without spaces. With no exported SDK, the existing local Mac validation cache is used. The private signing key is never needed for compilation. A signed image is required before installation.

The build output includes a generic full-flash command. Do not use it on a provisioned board: it can replace identity, recovery or the active application. `stage_validation.py` is restricted to the known reversible second validation board; it is not a shipping-device installer.

The exact R2 pin and memory contract is documented in `docs/BOARD-CONTRACT.md`. GPIO19/20 remain assigned to native USB; no firmware helper in this branch silently burns hardware security eFuses.
