# R2 firmware contract

The ordered release is `SpotifyDongle/releases/R2/KiCad/SpotifyDongle.kicad_sch` and the matching PCB. The released files, rather than older README pin assignments, are authoritative.

| Function | R2 connection |
| --- | --- |
| MCU | DOIT ESPS3-32-N16R8 / ESP32-S3 rev 0.2 |
| Flash | 16 MiB, quad, DIO |
| PSRAM | 8 MiB, octal, 80 MHz, startup memory test |
| PCM5102A BCK / LRCK / DOUT | GPIO 4 / 5 / 6 |
| PCM5102A XSMT | GPIO 7, low mutes |
| IR MOSFET gate | GPIO 8, active high, idle low |
| Native USB D− / D+ | GPIO 19 / 20, reserved permanently |
| PSRAM occupied pins | GPIO 35–37, reserved |

The USB Serial/JTAG console and ROM USB download route must remain usable. No deep sleep, light sleep, GPIO reassignment of USB, USB-disable eFuse changes, secure-boot eFuse provisioning, or flash-encryption eFuse provisioning is part of bench bring-up. Panic recovery reboots automatically. Both OTA slots and a separate factory recovery image are present.

## Required behavior

Requirements were recovered from the original 2026-08-29 spreadsheet. `original-requirements.json` preserves the source path, hash and extracted cells. Relevant software rows are D32–D50.

- Standalone Spotify Connect and AirPlay 1, with no Linux or media-server dependency.
- Saved Wi-Fi, phone setup portal, credential change/erase, automatic reconnection; a secured setup AP after 120 seconds offline, immediately if no network is configured.
- Single active source; the newest source cleanly takes over.
- Digital volume, mute during startup, B&O A.AUX wake before audible playback, and a smooth fade.
- Five minutes continuously paused/stopped/disconnected triggers standby. Digital silence within active playback is not idle.
- USB updates and dual-slot OTA with failed-boot rollback; service access through USB without opening the case.
- Secure credential storage and commercially usable dependency licences. Bench firmware must not claim these complete merely because credentials are omitted from release files.

## Evidence

kicad_sch SHA-256: `2a151a588d2ffd068f94fc6ea5df79ba61653a4a246ed6accbc098640aab911c`.

kicad_pcb SHA-256: `9425910768f616564693b7e37ca3d7cd5ede355988e138482573f98451543a36`.

The original full flash was backed up before writing. It was blank. Original SHA-256: `dffab0dd410657cb30c7b2fd7f2586a4792e8472e58882b3532581f8111a646d`.

`tools/check_image.py` checks the compiled board configuration and partition sizes before flashing. `tools/serial_console.py` suppresses DTR/RTS transitions so observing logs cannot accidentally reset the board. Provisioning material lives under `private/`, separately from release binaries.
