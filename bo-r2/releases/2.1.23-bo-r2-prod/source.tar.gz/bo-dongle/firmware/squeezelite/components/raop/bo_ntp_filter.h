#pragma once
#include <stdint.h>
#include <stdbool.h>

/* AirPlay 1 timing replies. The original mapping paired the sender's receive
 * stamp with our send time, so each reply carried the whole uplink delay, and
 * every reply replaced the last one. iPhones and Macs in Wi-Fi power save add
 * tens of milliseconds to single replies; that jitter reached the clock error
 * and triggered audible skip/pause resynchronisations. Pair the local and
 * remote midpoints and keep the lowest-delay reply of a short window. */
#define BO_NTP_WINDOW 16
#define BO_NTP_MS(ntp) ((((ntp) >> 10) * 1000L) >> 22)

typedef struct { uint32_t local_ms; uint64_t remote; uint32_t rtt_ms; bool valid; } bo_ntp_sample_t;
typedef struct { bo_ntp_sample_t samples[BO_NTP_WINDOW]; unsigned next; } bo_ntp_filter_t;

/* sent/received are local ms; remote_rx/remote_tx are 64-bit NTP stamps. */
static inline bo_ntp_sample_t bo_ntp_sample(uint32_t sent,uint32_t received,uint64_t remote_rx,uint64_t remote_tx) {
    uint32_t total=received-sent;
    uint64_t hold=remote_tx>remote_rx?remote_tx-remote_rx:0;
    uint32_t hold_ms=(uint32_t)BO_NTP_MS(hold);
    // A reply cannot be held longer than its round trip; ignore a bogus hold.
    if(hold_ms>total){hold_ms=0;hold=0;}
    return (bo_ntp_sample_t){.local_ms=sent+total/2,.remote=remote_rx+hold/2,.rtt_ms=total-hold_ms,.valid=true};
}

/* Returns the lowest-delay sample still in the window. On ties prefer the
 * newest one so the mapping follows slow drift between the two clocks. */
static inline bo_ntp_sample_t bo_ntp_filter_push(bo_ntp_filter_t *f,bo_ntp_sample_t sample) {
    f->samples[f->next%BO_NTP_WINDOW]=sample;
    unsigned newest=f->next++%BO_NTP_WINDOW;
    bo_ntp_sample_t best=sample;
    for(unsigned age=1;age<BO_NTP_WINDOW;age++) {
        const bo_ntp_sample_t *s=&f->samples[(newest+BO_NTP_WINDOW-age)%BO_NTP_WINDOW];
        if(s->valid && s->rtt_ms<best.rtt_ms)best=*s;
    }
    return best;
}
